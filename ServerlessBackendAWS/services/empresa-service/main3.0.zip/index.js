"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utilities_1 = require("./utilities");
const aws_proxy_1 = require("./aws-proxy");
const sidecar_1 = require("./sidecar");
const validators_1 = require("./validators");
const schema_1 = require("./schema");
const fs_1 = require("fs");
var AllowedOperation;
(function (AllowedOperation) {
    AllowedOperation["GetInstituto"] = "GetInstituto";
    AllowedOperation["CreateInstituto"] = "CreateInstituto";
    AllowedOperation["UpdateInstituto"] = "UpdateInstituto";
    AllowedOperation["DeleteInstituto"] = "DeleteInstituto";
})(AllowedOperation || (AllowedOperation = {}));
var HandlerError;
(function (HandlerError) {
    HandlerError["DependencyResolverNotAvailable"] = "DependencyResolverNotAvailable";
    HandlerError["OperationNotAllowed"] = "OperationNotAllowed";
    HandlerError["ObjectIdNotAvailable"] = "ObjectIdNotAvailable";
    HandlerError["InvalidEventBody"] = "InvalidEventBody";
    HandlerError["InvalidObjectBody"] = "InvalidObjectBody";
})(HandlerError || (HandlerError = {}));
const lakeName = process.env.SERVICE_LAKE_ARN || 'thisBucket';
const tableName = process.env.SERVICE_TABLE_ARN || 'thisTable';
const topicArn = process.env.SERVICE_TOPIC_ARN || 'thisTopic';
const isLambda = !!(process.env.LAMBDA_TASK_ROOT || false);
var mockResolver;
function getObjectId(event) {
    const operation = getOperation(event);
    if (operation === AllowedOperation.CreateInstituto) {
        const generated = utilities_1.UUID.newUUID();
        return generated;
    }
    else if (operation === AllowedOperation.DeleteInstituto || operation === AllowedOperation.UpdateInstituto || operation === AllowedOperation.GetInstituto) {
        const objectPath = event.path.split('/');
        const objectId = objectPath[objectPath.length - 1];
        return objectId;
    }
    else {
        return null;
    }
}
function parseObjectKey(objectId) { return { id: objectId }; }
function getOperation(event) {
    const operation = event.httpMethod;
    if (operation.toLowerCase() === 'get') {
        return AllowedOperation.GetInstituto;
    }
    else if (operation.toLowerCase() === 'post') {
        return AllowedOperation.CreateInstituto;
    }
    else if (operation.toLowerCase() === 'put') {
        return AllowedOperation.UpdateInstituto;
    }
    else if (operation.toLowerCase() === 'delete') {
        return AllowedOperation.DeleteInstituto;
    }
    else {
        return null;
    }
}
function getDependencyResolver(context) {
    const awsConfig = {
        appName: process.env.APP_NAME || 'TemporaryAppName',
        metricStorage: 60 * 5,
        functionName: context.functionName,
        functionStage: context.invokedFunctionArn,
        functionVersion: context.functionVersion
    };
    const resolver = isLambda ? new aws_proxy_1.AWSProxyResolver(awsConfig) : mockResolver;
    return new Promise((resolve, reject) => {
        if (resolver === null || resolver === undefined) {
            const error = utilities_1.ErrorHelper.newError(HandlerError.DependencyResolverNotAvailable, '', context);
            reject(error);
        }
        else {
            resolve(resolver);
        }
    });
}
function injetResolver(resolver) { mockResolver = resolver; }
exports.injetResolver = injetResolver;
function handler(event, context, callback) {
    process.on('unhandledRejection', (reason, p) => {
        console.log('Unhandled Rejection at: Promise', p, 'reason:', reason);
    });
    const traceId = context.awsRequestId;
    const operation = getOperation(event);
    if (operation === null || operation === undefined) {
        const error = HandlerError.OperationNotAllowed;
        const message = `${JSON.stringify(error)}! TraceId:${traceId}`;
        publishErrorInContingence(message, event, context);
        const response = utilities_1.ResponseBuilder.internalError(message, traceId);
        callback(null, response);
        return;
    }
    const objectId = getObjectId(event);
    if (objectId === null || objectId === undefined) {
        const error = HandlerError.ObjectIdNotAvailable;
        const message = `${JSON.stringify(error)}! TraceId:${traceId}`;
        publishErrorInContingence(message, event, context);
        const response = utilities_1.ResponseBuilder.internalError(message, traceId);
        callback(null, response);
        return;
    }
    getDependencyResolver(context).then(resolver => {
        const sidecar = new sidecar_1.Sidecar(resolver, context, traceId, operation.toString());
        const isValidAPIGatewayEvent = validators_1.Validators.isValidAPIGatewayEvent(event);
        if (!isValidAPIGatewayEvent) {
            const error = { code: HandlerError.InvalidEventBody, httpStatusCode: utilities_1.HttpStatusCode.badRequest };
            const response = sidecar.createErrorResponse(error);
            return sidecar.publishError(error, JSON.stringify(event))
                .then(serviceError => sidecar.sendResponse(response, callback));
        }
        const businessEvent = { default: `${operation}:${objectId}`, operation: operation, objectId: objectId };
        const successEvent = {
            topicArn: topicArn,
            body: { TopicArn: topicArn, MessageStructure: 'json', Message: JSON.stringify(businessEvent) }
        };
        if (operation === AllowedOperation.GetInstituto) {
            return sidecar.getInTable(tableName, parseObjectKey(objectId))
                .then(object => sidecar.createResponse(event, object, objectId))
                .then(response => sidecar.sendResponse(response, callback))
                .catch(sidecarError => {
                const response = sidecar.createErrorResponse(sidecarError);
                sidecar.sendResponse(response, callback);
            });
        }
        else if (operation == AllowedOperation.DeleteInstituto) {
            return sidecar.userIsAuthorizedToPerformOperation(event)
                .then(userIsAuthorized => sidecar.persistOnLake(lakeName, objectId, event))
                .then(persistedInLake => sidecar.persistInTable(tableName, event.httpMethod, parseObjectKey(objectId), JSON.parse(event.body)))
                .then(persisted => sidecar.publishEvent(topicArn, successEvent, event))
                .then(eventPublished => sidecar.createResponse(event, event.body, objectId))
                .then(response => sidecar.sendResponse(response, callback))
                .catch(sidecarError => {
                const response = sidecar.createErrorResponse(sidecarError);
                sidecar.sendResponse(response, callback);
            });
        }
        else {
            var updatedId = Object.assign({}, JSON.parse(event.body));
            updatedId = Object.assign(updatedId, { id: objectId });
            return validators_1.Validators.isValidObject(schema_1.Instituto, updatedId)
                .then(objectIsValid => sidecar.userIsAuthorizedToPerformOperation(event))
                .then(userIsAuthorized => sidecar.persistOnLake(lakeName, traceId, event))
                .then(persistedOnLake => {
                const newObject = Object.assign(JSON.parse(event.body), { id: objectId });
                sidecar.persistInTable(tableName, event.httpMethod, parseObjectKey(objectId), newObject);
            })
                .then(persisted => sidecar.publishEvent(topicArn, successEvent, event))
                .then(eventPublished => sidecar.createResponse(event, event.body, objectId))
                .then(response => sidecar.sendResponse(response, callback))
                .catch(sidecarError => {
                const response = sidecar.createErrorResponse(sidecarError);
                sidecar.sendResponse(response, callback);
            }).catch(error => { console.log('reach the last catch block'); });
        }
    }).catch(error => {
        const traceId = context.awsRequestId;
        const message = `${JSON.stringify(error)}! TraceId:${traceId}`;
        publishErrorInContingence(message, event, context);
        const response = utilities_1.ResponseBuilder.internalError(message, traceId);
        callback(null, response);
        return;
    }).catch(error => { console.log('reach the last catch block'); });
}
exports.handler = handler;
function publishErrorInContingence(message, payload, context) {
    if (!isLambda) {
        if (!fs_1.existsSync('./testreports')) {
            fs_1.mkdirSync('./testreports');
        }
        const filename = new Date().getTime() + '.txt';
        fs_1.writeFileSync('./testreports/console_' + filename, `Publishing Error in Contigence! -> ${message}`, 'utf-8');
    }
    else {
        console.error(`Publishing Error in Contigence! -> ${message}`);
        console.error(message);
    }
}
