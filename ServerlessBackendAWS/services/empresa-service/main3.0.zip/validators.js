"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utilities_1 = require("./utilities");
var ValueType;
(function (ValueType) {
    ValueType[ValueType["array"] = 0] = "array";
    ValueType[ValueType["object"] = 1] = "object";
    ValueType[ValueType["string"] = 2] = "string";
    ValueType[ValueType["number"] = 3] = "number";
    ValueType[ValueType["date"] = 4] = "date";
})(ValueType = exports.ValueType || (exports.ValueType = {}));
class Validators {
    static isValidEmail(value) { return true; }
    static isValidUUID(value) { return true; }
    static isValidAPIGatewayEvent(value) { return true; }
    static isValidSNSEvent(value) { return true; }
    static isValidSQSEvent(value) { return true; }
    static isValidS3Event(value) { return true; }
    static isValidDynamoEvent(value) { return true; }
    static isValidKinesisEvent(value) { return true; }
    static isValidTopicArn(arn) { return true; }
    static isValidObject(schema, object) {
        return new Promise((resolve, reject) => {
            const required = schema.required;
            for (var name in required) {
                if (!object.hasOwnProperty(name)) {
                    const error = { code: 'InvalidObjectBody', httpStatusCode: utilities_1.HttpStatusCode.badRequest };
                    reject(error);
                }
            }
            resolve(true);
        });
    }
}
exports.Validators = Validators;
