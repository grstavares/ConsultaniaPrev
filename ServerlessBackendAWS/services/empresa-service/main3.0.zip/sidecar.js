"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = require("fs");
const utilities_1 = require("./utilities");
const isLambda = !!(process.env.LAMBDA_TASK_ROOT || false);
var SidecarError;
(function (SidecarError) {
    SidecarError["UserNotAuthorized"] = "UserNotAuthorized";
    SidecarError["ResourceNotFound"] = "ResourceNotFound";
    SidecarError["InvalidObjectBody"] = "InvalidObjectBody";
    SidecarError["InvalidOperation"] = "InvalidOperation";
    SidecarError["InvalidConfiguration"] = "InvalidConfiguration";
    SidecarError["DependencyError"] = "DependencyError";
    SidecarError["ConfigurationNotAvailable"] = "ConfigurationNotAvailable";
    SidecarError["undefined"] = "undefined";
})(SidecarError = exports.SidecarError || (exports.SidecarError = {}));
exports.SidecarMetric = {
    DependencyError: 'DependencyError',
    undefined: 'undefined'
};
class Sidecar {
    constructor(dependencyResolver, lambdaContext, traceId, operation) {
        this.dependencyResolver = dependencyResolver;
        this.lambdaContext = lambdaContext;
        this.trail = [];
        this.traceId = traceId;
        this.operation = operation;
    }
    getParameter(parameter) {
        if (parameter.type === 'ENV') {
            return process.env[parameter.name];
        }
        else {
            return '';
        }
    }
    userIsAuthorizedToPerformOperation(event) {
        const trace = new OperationBuilder(this.traceId, this.operation).withAction('userIsAuthorizedToPerformOperation');
        return new Promise((resolve, reject) => {
            if (this.matchPermissions()) {
                this.trail.push(trace.build());
                resolve(true);
            }
            else {
                const error = {
                    error: SidecarError.UserNotAuthorized,
                    payload: 'empty',
                    parameters: {
                        userId: event.requestContext.identity.userArn,
                        checkedPolicies: JSON.stringify(['policA', 'policyB'])
                    }
                };
                this.trail.push(trace.withError(error).build());
                reject(error);
            }
        });
    }
    persistOnLake(bucketName, eventId, event) {
        const parameters = { bucketName: bucketName, eventId: eventId };
        const trace = new OperationBuilder(this.traceId, this.operation).withAction('persistOnLake').withPayload(event.body).withParameters(parameters);
        const bucket = this.dependencyResolver.bucket('region', bucketName);
        return new Promise((resolve, reject) => {
            if (bucket) {
                bucket.putObject(eventId + '.json', JSON.stringify(event)).then(success => {
                    this.trail.push(trace.build());
                    resolve(true);
                }).catch(error => {
                    const parameters = { resourceType: 'bucket', resourceName: bucketName };
                    this.trail.push(trace.withError(error).withParameters(parameters).build());
                    const metric = new utilities_1.MetricBuilder(exports.SidecarMetric.DependencyError, 1).withResourceType('bucket').withResource(bucketName).build();
                    this.publishMetric(metric)
                        .then(value => reject(error))
                        .catch(publishingError => {
                        this.publishErrorInContingence(JSON.stringify(error));
                        this.publishErrorInContingence(publishingError);
                        reject(error);
                    });
                });
            }
            else {
                const parameters = { resourceType: 'bucket', resourceName: bucketName };
                const error = { code: SidecarError.DependencyError, httpStatusCode: 500, resource: bucketName, payload: event };
                this.trail.push(trace.withError(error).withParameters(parameters).build());
                const metric = new utilities_1.MetricBuilder(exports.SidecarMetric.DependencyError, 1).withResourceType('bucket').withResource(bucketName).build();
                this.publishMetric(metric)
                    .then(value => reject(error))
                    .catch(publishingError => {
                    this.publishErrorInContingence(JSON.stringify(error));
                    this.publishErrorInContingence(publishingError);
                    reject(error);
                });
            }
        });
    }
    getInTable(tableName, keys) {
        const parameters = { tableName: tableName, key: keys };
        const trace = new OperationBuilder(this.traceId, this.operation).withAction('getInTable').withParameters(parameters);
        const table = this.dependencyResolver.table(tableName);
        return new Promise((resolve, reject) => {
            if (table) {
                table.getItem(keys).then((object) => {
                    if (object) {
                        this.trail.push(trace.build());
                        resolve(object);
                    }
                    else {
                        const error = { code: SidecarError.ResourceNotFound, httpStatusCode: 404, resource: tableName + '/' + JSON.stringify(keys) };
                        this.trail.push(trace.withError(error).withParameters(parameters).build());
                        reject(error);
                    }
                }).catch((error) => {
                    const parameters = { resourceType: 'table', resourceName: tableName };
                    this.trail.push(trace.withError(error).withParameters(parameters).build());
                    const metric = new utilities_1.MetricBuilder(exports.SidecarMetric.DependencyError, 1).withResourceType('table').withResource(tableName).build();
                    this.publishMetric(metric)
                        .then(value => reject(error))
                        .catch(publishingError => {
                        this.publishErrorInContingence(JSON.stringify(error));
                        this.publishErrorInContingence(publishingError);
                        reject(error);
                    });
                });
            }
            else {
                const parameters = { resourceType: 'table', resourceName: tableName };
                const error = { code: SidecarError.DependencyError, httpStatusCode: 500, resource: tableName, payload: null };
                this.trail.push(trace.withError(error).withParameters(parameters).build());
                const metric = new utilities_1.MetricBuilder(exports.SidecarMetric.DependencyError, 1).withResourceType('table').withResource(tableName).build();
                this.publishMetric(metric)
                    .then(value => reject(error))
                    .catch(publishingError => {
                    this.publishErrorInContingence(JSON.stringify(error));
                    this.publishErrorInContingence(publishingError);
                    reject(error);
                });
            }
        });
    }
    persistInTable(tableName, operation, keys, content) {
        const parameters = { tableName: tableName, key: keys, operation: operation };
        const trace = new OperationBuilder(this.traceId, this.operation).withAction('persistInTable').withPayload(JSON.stringify(content)).withParameters(parameters);
        const table = this.dependencyResolver.table(tableName);
        return new Promise((resolve, reject) => {
            if (table) {
                if (operation.toLowerCase() === 'post' || operation.toLowerCase() === 'put') {
                    table.putItem(keys, content).then(success => {
                        this.trail.push(trace.build());
                        resolve(true);
                    }).catch(error => {
                        const parameters = { resourceType: 'table', resourceName: tableName };
                        this.trail.push(trace.withError(error).withParameters(parameters).build());
                        const metric = new utilities_1.MetricBuilder(exports.SidecarMetric.DependencyError, 1).withResourceType('table').withResource(tableName).build();
                        this.publishMetric(metric)
                            .then(value => reject(error))
                            .catch(publishingError => {
                            this.publishErrorInContingence(JSON.stringify(error));
                            this.publishErrorInContingence(publishingError);
                            reject(error);
                        });
                    });
                }
                else if (operation.toLowerCase() === 'delete') {
                    table.deleteItem(keys).then(success => {
                        this.trail.push(trace.build());
                        resolve(true);
                    }).catch(error => {
                        const parameters = { resourceType: 'table', resourceName: tableName };
                        this.trail.push(trace.withError(error).withParameters(parameters).build());
                        const metric = new utilities_1.MetricBuilder(exports.SidecarMetric.DependencyError, 1).withResourceType('table').withResource(tableName).build();
                        this.publishMetric(metric)
                            .then(value => reject(error))
                            .catch(publishingError => {
                            this.publishErrorInContingence(JSON.stringify(error));
                            this.publishErrorInContingence(publishingError);
                            reject(error);
                        });
                    });
                }
                else {
                    const parameters = { resourceType: 'table', resourceName: tableName };
                    const error = { code: SidecarError.InvalidOperation, httpStatusCode: 500, resource: tableName, payload: content };
                    this.trail.push(trace.withError(error).withParameters(parameters).build());
                    const metric = new utilities_1.MetricBuilder(exports.SidecarMetric.DependencyError, 1).withResourceType('table').withResource(tableName).build();
                    this.publishMetric(metric)
                        .then(value => reject(error))
                        .catch(publishingError => {
                        this.publishErrorInContingence(JSON.stringify(error));
                        this.publishErrorInContingence(publishingError);
                        reject(error);
                    });
                }
            }
            else {
                const parameters = { resourceType: 'table', resourceName: tableName };
                const error = { code: SidecarError.DependencyError, httpStatusCode: 500, resource: tableName, payload: content };
                this.trail.push(trace.withError(error).withParameters(parameters).build());
                const metric = new utilities_1.MetricBuilder(exports.SidecarMetric.DependencyError, 1).withResourceType('table').withResource(tableName).build();
                this.publishMetric(metric)
                    .then(value => reject(error))
                    .catch(publishingError => {
                    this.publishErrorInContingence(JSON.stringify(error));
                    this.publishErrorInContingence(publishingError);
                    reject(error);
                });
            }
        });
    }
    publishEvent(topicArn, businessEvent, event) {
        const trace = new OperationBuilder(this.traceId, this.operation).withAction('publishEvent').withPayload(JSON.stringify(businessEvent));
        const topic = this.dependencyResolver.topic(topicArn);
        return new Promise((resolve, reject) => {
            if (topic) {
                topic.publish(businessEvent.body).then(messageId => {
                    const parameters = { messageId: messageId };
                    this.trail.push(trace.withParameters(parameters).build());
                    resolve(true);
                }).catch(error => {
                    const parameters = { resourceType: 'topic', resourceName: topicArn };
                    this.trail.push(trace.withError(error).withParameters(parameters).build());
                    const metric = new utilities_1.MetricBuilder(exports.SidecarMetric.DependencyError, 1).withResourceType('topic').withResource(topicArn).build();
                    this.publishMetric(metric)
                        .then(value => reject(error))
                        .catch(publishingError => {
                        this.publishErrorInContingence(JSON.stringify(error));
                        this.publishErrorInContingence(publishingError);
                        reject(error);
                    });
                });
            }
            else {
                const parameters = { resourceType: 'topic', resourceName: topicArn };
                const error = { code: SidecarError.DependencyError, httpStatusCode: 500, resource: topicArn, payload: event };
                this.trail.push(trace.withError(error).withParameters(parameters).build());
                const metric = new utilities_1.MetricBuilder(exports.SidecarMetric.DependencyError, 1).withResourceType('topic').withResource(topicArn).build();
                this.publishMetric(metric)
                    .then(value => reject(error))
                    .catch(publishingError => {
                    this.publishErrorInContingence(JSON.stringify(error));
                    this.publishErrorInContingence(publishingError);
                    reject(error);
                });
            }
        });
    }
    publishMetric(metricValue) {
        const trace = new OperationBuilder(this.traceId, this.operation).withAction('publishMetric').withPayload(JSON.stringify(metricValue));
        const metric = this.dependencyResolver.metric();
        return new Promise((resolve, reject) => {
            if (metric) {
                metric.publish(metricValue)
                    .then(success => {
                    this.trail.push(trace.build());
                    resolve(true);
                }).catch(error => {
                    const parameters = { resourceType: 'metric', resourceName: metricValue.name };
                    this.trail.push(trace.withError(error).withParameters(parameters).build());
                    const metric = new utilities_1.MetricBuilder(exports.SidecarMetric.DependencyError, 1).withResourceType('metric').withResource(metricValue.name).build();
                    this.publishErrorInContingence(JSON.stringify(metric));
                    reject(error);
                });
            }
            else {
                const parameters = { resourceType: 'metric', resourceName: metricValue.name };
                const error = { code: SidecarError.DependencyError, httpStatusCode: 500, resource: metricValue.name, payload: event };
                this.trail.push(trace.withError(error).withParameters(parameters).build());
                const metric = new utilities_1.MetricBuilder(exports.SidecarMetric.DependencyError, 1).withResourceType('metric').withResource(metricValue.name).build();
                this.publishErrorInContingence(JSON.stringify(metric));
                reject(error);
            }
        });
    }
    publishError(error, payload) {
        let e = new Error();
        let frame = e.stack.split("\n")[2];
        let lineNumber = frame.split(":")[1];
        let functionName = frame.split(" ")[5];
        const parameters = { function: functionName, line: lineNumber, error: error };
        const trace = new OperationBuilder(this.traceId, this.operation).withAction('publishError').withParameters(parameters).withPayload(JSON.stringify(payload));
        return new Promise((resolve, reject) => {
            this.trail.push(trace.build());
            resolve(error);
        });
    }
    createResponse(event, content, objectId) {
        var result;
        const operation = event.httpMethod.toLowerCase();
        if (operation == 'post') {
            const url = event.path + '/' + objectId;
            result = utilities_1.ResponseBuilder.created(url, content);
        }
        else if (operation == 'delete') {
            result = utilities_1.ResponseBuilder.ok(null);
        }
        else if (operation == 'put' || operation == 'get') {
            result = utilities_1.ResponseBuilder.ok(content);
        }
        return result;
    }
    createErrorResponse(error) {
        switch (error.code) {
            case 'UserNotAuthorized': return utilities_1.ResponseBuilder.forbidden(error.code, this.traceId);
            case 'ResourceNotFound': return utilities_1.ResponseBuilder.notFound(error.code, this.traceId);
            case 'InvalidObjectBody': return utilities_1.ResponseBuilder.badRequest(error.code, this.traceId);
            case 'InvalidOperation': return utilities_1.ResponseBuilder.badRequest(error.code, this.traceId);
            case 'InvalidConfiguration': return utilities_1.ResponseBuilder.internalError(error.code, this.traceId);
            case 'DependencyNotAvailable': return utilities_1.ResponseBuilder.internalError(error.code, this.traceId);
            case 'DependencyError': return utilities_1.ResponseBuilder.internalError(error.code, this.traceId);
            case 'ConfigurationNotAvailable': return utilities_1.ResponseBuilder.internalError(error.code, this.traceId);
            default: return utilities_1.ResponseBuilder.internalError(error.code, this.traceId);
        }
    }
    sendResponse(response, callback) {
        this.publishOperationTrail();
        callback(null, response);
    }
    matchPermissions() { return true; }
    publishOperationTrail() {
        if (!isLambda) {
            if (!fs_1.existsSync('./testreports')) {
                fs_1.mkdirSync('./testreports');
            }
            const filename = new Date().getTime() + '.json';
            fs_1.writeFileSync('./testreports/lambdaexecution' + filename, JSON.stringify(this.trail, null, 2), 'utf-8');
        }
    }
    publishErrorInContingence(message) {
        if (!isLambda) {
            if (!fs_1.existsSync('./testreports')) {
                fs_1.mkdirSync('./testreports');
            }
            const filename = new Date().getTime() + '.txt';
            fs_1.writeFileSync('./testreports/console_' + filename, `Publishing Error in Contigence! -> ${message}`, 'utf-8');
        }
        else {
            console.error('Publishing Error in Contigence!');
            console.error(message);
        }
    }
}
exports.Sidecar = Sidecar;
class SidecarOperation {
    constructor(builder) {
        this.traceId = builder.traceId;
        this.operation = builder.operation;
        this.timestamp = builder.timestamp;
        this.durationInMillis = builder.durationInMillis;
        this.action = builder.action;
        this.success = builder.success;
        this.parameters = builder.parameters;
        this.payload = builder.payload;
        this.error = builder.error;
    }
}
exports.SidecarOperation = SidecarOperation;
class OperationBuilder {
    constructor(traceId, operation) { this.traceId = traceId; this.operation = operation; this.timestamp = new Date(); }
    withAction(name) { this.action = name; return this; }
    withParameters(object) { this.parameters = object; return this; }
    withPayload(object) { this.payload = object; return this; }
    withError(error) { this.error = error; return this; }
    build() {
        const now = new Date();
        this.durationInMillis = (now.getTime() - this.timestamp.getTime());
        if (this.error === null || this.error === undefined) {
            this.success = true;
        }
        else {
            this.success = false;
        }
        return new SidecarOperation(this);
    }
}
