"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
const aws_helper_1 = require("./aws-helper");
var XRay = require('aws-xray-sdk');
class AWSProxyResolver {
    constructor(config) {
        this.config = config;
        this.topicsCache = [];
        this.bucketCache = [];
        this.metricCache = [];
        this.tablesCache = [];
        XRay.enableManualMode();
    }
    topic(arn) {
        const objectKey = 'topic_' + arn;
        const cached = this.topicsCache.filter((value) => { value.key === objectKey; });
        if (cached.length > 0) {
            return cached[0].object;
        }
        else {
            return new AWSTopic(arn);
        }
    }
    bucket(region, name) {
        const objectKey = 'bucket_' + region + name;
        const cached = this.bucketCache.filter((value) => { value.key === objectKey; });
        if (cached.length > 0) {
            return cached[0].object;
        }
        else {
            return new AWSBucket(region, name);
        }
    }
    metric() {
        const objectKey = 'metric_' + this.config.appName;
        const cached = this.metricCache.filter((value) => { value.key === objectKey; });
        if (cached.length > 0) {
            return cached[0].object;
        }
        else {
            return new AWSMetric(this.config);
        }
    }
    table(arn) {
        const dynamoClient = XRay.captureAWSClient((new aws_sdk_1.DynamoDB).service);
        const documentClient = new aws_sdk_1.DynamoDB.DocumentClient();
        const objectKey = 'table_' + arn;
        const cached = this.tablesCache.filter((value) => { value.key === objectKey; });
        if (cached.length > 0) {
            return cached[0].object;
        }
        else {
            return new AWSTable(dynamoClient, documentClient, arn);
        }
    }
}
exports.AWSProxyResolver = AWSProxyResolver;
class AWSTopic {
    constructor(arn) {
        this.arn = arn;
        this.Errors = {
            invalidArn: 'invalidConfiguration'
        };
    }
    publish(message) {
        return new Promise((resolve, reject) => {
            const sns = new aws_sdk_1.SNS();
            const snsEvent = { Message: JSON.stringify(message), TopicArn: this.arn };
            sns.publish(snsEvent, (error, data) => {
                if (error) {
                    reject(aws_helper_1.AwsHelper.parseAWSError(error, { type: 'topic', name: this.arn }));
                }
                else {
                    resolve(data.MessageId);
                }
            });
        });
    }
    validateArnAndReturnRegion(arn) {
        let splitedTopicArn = arn.split(":");
        if (splitedTopicArn.length < 7) {
            return undefined;
        }
        return splitedTopicArn[3];
    }
}
exports.AWSTopic = AWSTopic;
class AWSBucket {
    constructor(region, name) {
        this.region = region;
        this.name = name;
        this.s3 = new aws_sdk_1.S3();
    }
    getObject(key) {
        const getObjectParams = { Bucket: this.name, Key: key };
        return new Promise((resolve, reject) => {
            this.s3.getObject(getObjectParams, (error, data) => {
                if (error) {
                    reject(aws_helper_1.AwsHelper.parseAWSError(error, { type: 'bucket', name: this.name }));
                }
                else {
                    resolve(data);
                }
            });
            resolve(null);
        });
    }
    putObject(key, content) {
        const putObjectParams = {
            Bucket: this.name,
            Key: key,
            Body: JSON.stringify(content),
            ContentType: 'application/json',
        };
        return new Promise((resolve, reject) => {
            this.s3.putObject(putObjectParams, (error, data) => {
                if (error) {
                    reject(aws_helper_1.AwsHelper.parseAWSError(error, { type: 'bucket', name: this.name }));
                }
                else {
                    resolve(data);
                }
            });
            resolve(null);
        });
    }
}
exports.AWSBucket = AWSBucket;
class AWSMetric {
    constructor(configuration) {
        this.configuration = configuration;
        this.dimensions = [];
        this.cloudwatch = new aws_sdk_1.CloudWatch();
        this.dimensions.push({ Name: 'function', Value: configuration.functionName });
        this.dimensions.push({ Name: 'stage', Value: configuration.functionStage });
        this.dimensions.push({ Name: 'version', Value: configuration.functionVersion });
    }
    publish(metric) {
        return new Promise((resolve, reject) => {
            const newDimensions = metric.dimensions;
            for (var i = 0; i < newDimensions.length; i++) {
                this.dimensions.push(newDimensions[i]);
            }
            const metricData = {
                Namespace: this.configuration.appName,
                MetricData: [{
                        MetricName: metric.name,
                        Dimensions: this.dimensions,
                        Timestamp: metric.timestamp,
                        Value: metric.value,
                        Unit: 'Count',
                        StorageResolution: 60
                    }]
            };
            this.cloudwatch.putMetricData(metricData, (error, data) => {
                if (error) {
                    reject(aws_helper_1.AwsHelper.parseAWSError(error, { type: 'metric', name: metric.name }));
                }
                else {
                    resolve(true);
                }
            });
        });
    }
}
exports.AWSMetric = AWSMetric;
class AWSTable {
    constructor(dynamo, docClient, tableName) {
        this.dynamo = dynamo;
        this.docClient = docClient;
        this.tableName = tableName;
    }
    getItem(keys) {
        var getItemParams = { Key: keys, TableName: this.tableName, ReturnConsumedCapacity: 'TOTAL' };
        return new Promise((resolve, reject) => {
            this.dynamo.getItem(getItemParams).promise()
                .then(result => resolve(result.Item ? aws_helper_1.AwsHelper.unmarshalObject(result.Item) : null))
                .catch(error => reject(aws_helper_1.AwsHelper.parseAWSError(error, { type: 'table', name: this.tableName })));
        });
    }
    putItem(keys, object) {
        const payload = aws_helper_1.AwsHelper.marshalObject(object);
        const putObject = { 'TableName': this.tableName, 'Item': payload, ReturnConsumedCapacity: 'TOTAL' };
        return new Promise((resolve, reject) => {
            this.dynamo.putItem(putObject).promise()
                .then(result => {
                resolve(true);
            })
                .catch(error => {
                reject(aws_helper_1.AwsHelper.parseAWSError(error, { type: 'table', name: this.tableName }));
            });
        });
    }
    deleteItem(keys) {
        var deleteItemParams = { TableName: this.tableName, Key: keys, ReturnConsumedCapacity: 'TOTAL' };
        return new Promise((resolve, reject) => {
            this.dynamo.deleteItem(deleteItemParams).promise()
                .then(result => resolve(true))
                .catch(error => reject(aws_helper_1.AwsHelper.parseAWSError(error, { type: 'table', name: this.tableName })));
        });
    }
}
exports.AWSTable = AWSTable;
