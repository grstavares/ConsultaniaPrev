"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.HttpStatusCode = {
    ok: 200,
    created: 201,
    badRequest: 400,
    forbidden: 403,
    notFound: 404,
    internalServerError: 500,
};
class UUID {
    static newUUID() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }
}
exports.UUID = UUID;
class ResponseBuilder {
    static ok(result) { return ResponseBuilder.parseResponse(result, exports.HttpStatusCode.ok); }
    static created(url, result) {
        const headers = { Location: url };
        return ResponseBuilder.parseResponse(result, exports.HttpStatusCode.created, headers);
    }
    static badRequest(reason, traceId) {
        const error = ResponseBuilder.parseError(exports.HttpStatusCode.badRequest, reason, traceId);
        return ResponseBuilder.parseResponse(error, exports.HttpStatusCode.badRequest);
    }
    static forbidden(reason, traceId) {
        const error = ResponseBuilder.parseError(exports.HttpStatusCode.forbidden, 'REDACTED', traceId);
        return ResponseBuilder.parseResponse(error, exports.HttpStatusCode.forbidden);
    }
    static notFound(reason, traceId) {
        const error = ResponseBuilder.parseError(exports.HttpStatusCode.notFound, reason, traceId);
        return ResponseBuilder.parseResponse(error, exports.HttpStatusCode.notFound);
    }
    static internalError(reason, traceId) {
        const error = ResponseBuilder.parseError(exports.HttpStatusCode.internalServerError, 'REDACTED', traceId);
        return ResponseBuilder.parseResponse(error, exports.HttpStatusCode.internalServerError);
    }
    static parseError(statusCode, message, traceId) {
        const messageBody = message + (traceId ? ':TraceId -> ${traceId}' : '');
        return { error: { statusCode: statusCode, message: messageBody } };
    }
    static parseResponse(result, statusCode, headers) {
        const responseBody = result ? JSON.stringify(result) : null;
        const parsedHeaders = headers ? Object.assign(headers, ResponseBuilder.defaultHeaders) : ResponseBuilder.defaultHeaders;
        const response = {
            statusCode: statusCode,
            headers: parsedHeaders,
            body: responseBody
        };
        return response;
    }
}
ResponseBuilder.defaultHeaders = { 'Content-Type': 'application/json' };
exports.ResponseBuilder = ResponseBuilder;
class MetricBuilder {
    constructor(name, value) {
        this.dimensions = [];
        this.timestamp = new Date();
        this.name = name;
        this.value = value;
    }
    withResource(resourceName) { this.dimensions.push({ Name: 'Resource', Value: resourceName }); return this; }
    withResourceType(resourceName) { this.dimensions.push({ Name: 'ResourceType', Value: resourceName }); return this; }
    withDimension(dimensionName, dimensionValue) { this.dimensions.push({ Name: dimensionName, Value: dimensionValue }); return this; }
    build() {
        const metric = {
            timestamp: this.timestamp,
            name: this.name,
            value: this.value,
            dimensions: this.dimensions
        };
        return metric;
    }
}
exports.MetricBuilder = MetricBuilder;
class ErrorHelper {
    static newError(errorCode, resource, payload) {
        const error = { code: errorCode, httpStatusCode: 500, resource: resource, payload: payload };
        return error;
    }
}
exports.ErrorHelper = ErrorHelper;
class EnvironmentHelper {
    static getParameter(name) { return process.env[name]; }
}
exports.EnvironmentHelper = EnvironmentHelper;
