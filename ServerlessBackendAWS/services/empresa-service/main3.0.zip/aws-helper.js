"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
class AwsHelper {
    static marshalObject(object) {
        const marshsalled = aws_sdk_1.DynamoDB.Converter.marshall(object, { convertEmptyValues: true, wrapNumbers: true });
        return marshsalled;
    }
    static unmarshalObject(object) {
        const unmarshsalled = aws_sdk_1.DynamoDB.Converter.unmarshall(object, { convertEmptyValues: true, wrapNumbers: true });
        return unmarshsalled;
    }
    static parseAWSError(error, resource) {
        var errorCode = 'undefined';
        var httpCode = 500;
        var resourceDescription = resource ? JSON.stringify(resource) : 'undefined';
        switch (error.code.toLowerCase()) {
            case 'networkingerror':
                errorCode = 'NetworkError';
                httpCode = 500;
                break;
            case 'missingrequiredparameter':
                errorCode = 'InvalidObjectBody';
                httpCode = 400;
                break;
            default:
                break;
        }
        return { code: errorCode, httpStatusCode: httpCode, resource: resourceDescription, payload: error };
    }
    static getRegionFromArn(arn) {
        const splitted = arn.split(":");
        return splitted[3];
    }
}
exports.AwsHelper = AwsHelper;
